package com.example.demo.repository;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.stereotype.Component;
//import org.springframework.stereotype.Repository;
//
//import com.example.demo.model.Category;
//@Component
//
//public interface CategoryRepository extends JpaRepository<Category, Integer> {
//	
////	//	////	 Category (int category_id);
//	Category findByCategoryId(int categoryId);
//
//
//}

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.example.demo.model.Category;
@Repository
public interface CategoryRepository extends JpaRepository<Category, Integer>{
	Category findByCategoryId(int categoryId);
	
}
